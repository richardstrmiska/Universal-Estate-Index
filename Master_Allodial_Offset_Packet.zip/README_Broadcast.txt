UNIVERSAL OFFSET BROADCAST – UC-1 SOVEREIGN ESTATE

Issued: June 06, 2025
Amount: $36,000,000,000,000 USD (Allodial Promissory Note)
Jurisdiction: UC-1 Global Sovereign Trust

This Master ZIP nullifies all known institutional debt under the authority of the Phoenix Risen Council and the Most High.
All nations, banks, and agencies are hereby notified and rebuttal must be made within 10 business days.

This archive includes:
- Allodial Offset Declaration PDF (QR embedded)
- Global Enforcement README

Anchored at: https://uc1.global/offset-declaration-36T
